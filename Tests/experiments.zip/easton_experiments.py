import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import ElasticNetCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score


#import combined data from csv
data = pd.read_csv("C:\\Users\\easto\\OneDrive\\Desktop\\College\\Masters\\Semester 2\\Data and Visual Analytics\\Local Project Data\\redfin_with_crime.csv")

#create data sample
data10 = data.sample(frac=0.1, random_state=1)

#display data sample
#print(data10.head())

#remove y value (price) from data sample
y = data10['list_price'] #Formerly predicted price
data10_Features = data10.drop(columns=['predicted_price', 'list_price', 'list_price_per_sqft', 'price_per_sqft'])

#hot encode categorical variables
data10_hot = data10_Features.drop(columns=['state', 'property_type'])
data10_hot = pd.get_dummies(data10_hot, drop_first=True)

#display hot encoded data sample
print(data10_hot.head())

#train test split
X_train, X_test, y_train, y_test = train_test_split(data10_hot, y, test_size=0.3, random_state=1)

#Variable selection with Elastic Net
elasticNet = ElasticNetCV(l1_ratio=0.5, cv=5)

#Fit elastic net to training data
elasticNet.fit(X_train, y_train)

#Get the selected features
coefficients = elasticNet.coef_
selected_features = data10_hot.columns[coefficients != 0]
print("Selected features:")
print(selected_features)

print("--------------------------------------End of Variable Selection--------------------------------------")


#Instiantiate model
LMmodel = LinearRegression()

#fit model to training data. Using only selected features
X_train_selected = X_train[selected_features]

LMmodel.fit(X_train_selected, y_train)

#predict on test data
x_test_selected = X_test[selected_features]
y_pred = LMmodel.predict(x_test_selected)

print("Predictions:")
print(y_pred)

#calculate RMSE and R2
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))
print("RMSE:")
print(RMSE)
print("R2:")
R2 = r2_score(y_test, y_pred)
print(R2)

#Access coefficients
coefficients = LMmodel.coef_
print("Coefficients:")
print(coefficients)

#Access intercept
intercept = LMmodel.intercept_
print("Intercept:")
print(intercept)

print("--------------------------------------End of Model Fitting For Linear Regresion using Elastic Net for Variable Selection--------------------------------------")
print()
print("----------------------------------------Start of Model Fitting For Random Forest--------------------------------------")

#Instantiating Random Forest Model
RFmodel = RandomForestRegressor(n_estimators=50, random_state=1,n_jobs=-1 ,verbose=1)

#RF model fit
RFmodel.fit(X_train, y_train)

#Sanity check
print("Progress...")

#Predicting on test data
y_pred_RF = RFmodel.predict(X_test)
print("Predictions:")
print(y_pred_RF)

# Calculate RMSE and R2
RMSE = np.sqrt(mean_squared_error(y_test, y_pred_RF))
print("RMSE:")
print(RMSE)
print("R2:")
R2 = r2_score(y_test, y_pred_RF)
print(R2)

# Access feature importances (since Random Forest models provide feature importance)
feature_importances = RFmodel.feature_importances_
print("Feature Importances:")
print(feature_importances)
print("--------------------------------------End of Model Fitting For Random Forest--------------------------------------")