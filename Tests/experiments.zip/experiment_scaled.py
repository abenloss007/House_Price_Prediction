import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, ElasticNetCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import RandomizedSearchCV

# Import combined data from CSV
data = pd.read_csv("C:\\Users\\easto\\OneDrive\\Desktop\\College\\Masters\\Semester 2\\Data and Visual Analytics\\Local Project Data\\redfin_with_crime.csv")

# Create data sample
data10 = data.sample(frac=0.1, random_state=1)

# Define target variable
y = data10['list_price'] #Formerly predicted price
data10_Features = data10.drop(columns=['predicted_price', 'list_price', 'list_price_per_sqft', 'price_per_sqft'])

# One-hot encode categorical variables
data10_hot = data10_Features.drop(columns=['state', 'property_type'])
data10_hot = pd.get_dummies(data10_hot, drop_first=True)

# Display hot encoded data sample
print(data10_hot.head())

# Train/test split BEFORE scaling
X_train, X_test, y_train, y_test = train_test_split(data10_hot, y, test_size=0.3, random_state=1)

# Standardize full feature set for Elastic Net variable selection
scaler_full = StandardScaler()
X_train_scaled_full = scaler_full.fit_transform(X_train)
X_test_scaled_full = scaler_full.transform(X_test)

# Variable selection with Elastic Net
elasticNet = ElasticNetCV(l1_ratio=0.5, cv=5)
elasticNet.fit(X_train_scaled_full, y_train)

# Get the selected features
coefficients = elasticNet.coef_
selected_features = data10_hot.columns[coefficients != 0]
print("Selected features:")
print(selected_features)
print("--------------------------------------End of Variable Selection--------------------------------------")

# Use only selected features from original training/testing data
X_train_selected = X_train[selected_features]
X_test_selected = X_test[selected_features]

# Standardize selected features for linear regression
scaler_selected = StandardScaler()
X_train_selected_scaled = scaler_selected.fit_transform(X_train_selected)
X_test_selected_scaled = scaler_selected.transform(X_test_selected)

# Linear Regression Model
LMmodel = LinearRegression()
LMmodel.fit(X_train_selected_scaled, y_train)

# Predictions
y_pred = LMmodel.predict(X_test_selected_scaled)
print("Predictions:")
print(y_pred)

# Metrics
RMSE = np.sqrt(mean_squared_error(y_test, y_pred))
print("RMSE:")
print(RMSE)

R2 = r2_score(y_test, y_pred)
print("R2:")
print(R2)

# Coefficients and Intercept
print("Coefficients:")
print(LMmodel.coef_)

print("Intercept:")
print(LMmodel.intercept_)

print("--------------------------------------End of Model Fitting For Linear Regression using Elastic Net for Variable Selection--------------------------------------")

# This code is how I determined the parameter distribution. Using random search, we cut down the computation speed but we lose data.
'''
# Define parameter distribution
param_dist = {
    'n_estimators': [100, 200, 300, 500],
    'learning_rate': [0.01, 0.05, 0.1, 0.15],
    'max_depth': [3, 4, 5, 6],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 3, 5],
    'subsample': [0.8, 1.0],
    'max_features': ['sqrt', 'log2', None]
}

# Instantiate base model
gbr = GradientBoostingRegressor(random_state=1)

# Set up randomized search
rand_search = RandomizedSearchCV(
    estimator=gbr,
    param_distributions=param_dist,
    n_iter=50,               # Number of random combinations to try
    scoring='r2',            # Optimize for R² score
    cv=3,                    # 3-fold cross-validation
    verbose=2,
    n_jobs=-1,               # Use all available cores
    random_state=42
)

# Fit to training data
rand_search.fit(X_train, y_train)

# Print best parameters and score
print("Best Parameters Found:")
print(rand_search.best_params_)
print("Best Cross-Validated R² Score:")
print(rand_search.best_score_)

# Evaluate on test set
best_gbr = rand_search.best_estimator_
y_pred_best = best_gbr.predict(X_test)

rmse_best = np.sqrt(mean_squared_error(y_test, y_pred_best))
r2_best = r2_score(y_test, y_pred_best)

print("\nTest Set Evaluation")
print("RMSE:", rmse_best)
print("R²:", r2_best)
'''

# Instantiate Gradient Boosting model
GBmodel = GradientBoostingRegressor(
    subsample= 1.0, n_estimators= 500,
    min_samples_split= 2, min_samples_leaf= 1,
    max_features= None, max_depth= 4, learning_rate= 0.15
)

# Fit the model on untransformed target
GBmodel.fit(X_train, y_train)

# Predict on test data
y_pred_GB = GBmodel.predict(X_test)

# Evaluate performance
RMSE_GB = np.sqrt(mean_squared_error(y_test, y_pred_GB))
R2_GB = r2_score(y_test, y_pred_GB)

print("Predictions:")
print(y_pred_GB)
print("RMSE (Gradient Boosting):", RMSE_GB)
print("R² (Gradient Boosting):", R2_GB)

# Access feature importances
feature_importances_GB = GBmodel.feature_importances_
print("Feature Importances (Gradient Boosting):")
print(feature_importances_GB)
print("--------------------------------------End of Model Fitting For Gradient Boosting using Elastic Net for Variable Selection--------------------------------------")
